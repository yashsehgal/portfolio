// const homePagePath = PATH AFTER UPLOADING THIS SITE ONLINE;
const homePageName = "index.htm";
const homePageRelativePath = "/src/pages/index.htm";

let redirectToMainPage = function redirectToMainPage() {
  // console.log("main");
  console.log(
    "[filename: " + homePageName + ", filepath: " + homePageRelativePath + "]. This file is currently not available in the file system"
  );
};
